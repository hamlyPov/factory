Assets Folder:
Use for storing information of each company's neccessary file instead of placing it directly into the code.
In each company, there should be three folders including: 
	- requests/: object that is required during requesting data from company's API (can be xml or json)
	- json_response_model/: a standard json that store all standard fields of our final response and the compatible filed names of the response object from company's API 

	- test_response/: local object that represent http response data (can be xml or json) 
	