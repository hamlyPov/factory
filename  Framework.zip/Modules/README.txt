This folder "Modules" is a place to store all the common modules and function use through out the framework.
Example
- data_converter: a module that can convert from xml to json or from json to json
- network: allow us to send request to given url with required object parameter