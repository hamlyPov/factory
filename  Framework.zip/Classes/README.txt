This place "Classes" will store all the implemted class for each company.
Class creating rule and description

- The class AbstractService.py: is an abstract class that store all the function name that need to be implemented
- When creating a class we should follow some rules
	1. file name: have to be in lower case and use the company name as a name "company_name.py" (ex. dhl.py, parcel.py)
	2. class name: have to be in lower case and this class name will be use in url parameter
