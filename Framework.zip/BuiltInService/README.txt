Please use this folder as a virtual environment for importing built-in modules.
All built-in services should be located in one place here before uploading to lambda aws.

